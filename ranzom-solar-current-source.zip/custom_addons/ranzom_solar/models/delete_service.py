from odoo import api, models, _
from odoo.exceptions import AccessDenied, UserError


class RanzomSolarDeleteService(models.TransientModel):
    """Server-side password confirmation for destructive ERP actions.

    The current user's password is checked on the server. The caller's normal
    Odoo access rights and record rules are still enforced before unlinking.
    """

    _name = 'ranzom.solar.delete.service'
    _description = 'Ranzom Solar Protected Delete Service'

    _ALLOWED_MODELS = frozenset({
        'crm.lead',
        'ranzom.solar.followup',
        'ranzom.solar.quotation',
        'sale.order',
        'res.partner',
        'product.template',
        'purchase.order',
        'account.move',
        'hr.employee',
        'hr.attendance',
        'account.payment',
        'project.project',
        'project.task',
    })

    @api.model
    def verify_password_and_delete(self, model_name, record_id, password):
        """Verify the active user's password, then delete one allowed record."""
        if model_name not in self._ALLOWED_MODELS:
            raise UserError(_('Deletion is not enabled for this record type.'))

        try:
            self.env.user._check_credentials(
                {'type': 'password', 'password': password or ''},
                {'interactive': True},
            )
        except AccessDenied:
            raise UserError(_('The password is incorrect. The record was not deleted.'))

        try:
            record_id = int(record_id)
        except (TypeError, ValueError):
            raise UserError(_('Invalid record identifier.'))

        record = self.env[model_name].browse(record_id).exists()
        if not record:
            raise UserError(_('This record no longer exists. Refresh the page and try again.'))

        # Never sudo here: the current user's ACLs and record rules must apply.
        record.check_access_rights('unlink')
        record.check_access_rule('unlink')
        record.unlink()
        return True
